﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfCyientTest.Model
{
  public class Employee
    {
        private int _empID;
        private string _empName;
        private string _designation;
        private int _age;

        public int EmpID
        {
            get
            {
                return _empID;
            }
            set
            {
                _empID = value;
            }
        }

        public string EmpName
        {
            get
            {
                return _empName;
            }
            set
            {
                _empName = value;
            }
        }

        public string Designation
        {
            get
            {
                return _designation;
            }
            set
            {
                _designation = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }
    }
}
