﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WpfCyientTest.Command;
using WpfCyientTest.Model;

namespace WpfCyientTest.ViewModel
{
    public class EmployeeViewModel: ViewModelBase
    {
        public EmployeeViewModel()
        {
            Employee = new Employee();
            Employees = new ObservableCollection<Employee>();
        }

        private Employee _employee;
        private ObservableCollection<Employee> _employees;
        private ICommand _SubmitCommand;
        private ICommand _SerachCommand;
        private ICommand _updateCommand;
        private ICommand _deleteCommand;

        public Employee Employee
        {
            get
            {
                return _employee;
            }
            set
            {
                _employee = value;
                OnPropertyChanged("Employee");
            }

        }

        public ObservableCollection<Employee> Employees
        {
            get
            {
                return _employees;
            }
            set
            {
                _employees = value;
                OnPropertyChanged("Employees");
            }

        }

        public ICommand SubmitCommand
        {
            get
            {
                if (_SubmitCommand == null)
                {
                    _SubmitCommand = new RelayCommand(param => this.Submit(), null);
                }
                return _SubmitCommand;
            }
        }

        public ICommand SearchCommand
        {
            get
            {
                if (_SerachCommand == null)
                {
                    _SerachCommand = new RelayCommand(param => this.Search(), null);
                }
                return _SerachCommand;
            }
        }

        public ICommand UpdateCommand
        {
            get
            {
                if (_updateCommand == null)
                {
                    _updateCommand = new RelayCommand(param => this.Update(), null);
                }
                return _updateCommand;
            }
        }

        public ICommand DeleteCommand
        {
            get
            {
                if (_deleteCommand == null)
                {
                    _deleteCommand = new RelayCommand(param => this.Delete(), null);
                }
                return _deleteCommand;
            }
        }

        private void Submit()
        {            
            Employees.Add(Employee);
            Employee = new Employee();
        }
        private void Search()
        {
            Employee emp = this.Employees.FirstOrDefault(e => e.EmpID == this.Employee.EmpID);
            this.Employee.EmpName = emp.EmpName;
            this.Employee.Designation = emp.Designation;
            this.Employee.Age = emp.Age;            
            OnPropertyChanged("Employee");
        }

        private void Update()
        {
            Employee emp = this.Employees.FirstOrDefault(e => e.EmpID == this.Employee.EmpID);
            emp.EmpName = this.Employee.EmpName;
            emp.Designation = this.Employee.Designation;
            emp.Age = this.Employee.Age;            
            OnPropertyChanged("Employee");
        }

        private void Delete()
        {
            Employee emp = this.Employees.FirstOrDefault(e => e.EmpID == this.Employee.EmpID);
            this.Employees.Remove(emp);
            OnPropertyChanged("Employee");
        }

    }
}
